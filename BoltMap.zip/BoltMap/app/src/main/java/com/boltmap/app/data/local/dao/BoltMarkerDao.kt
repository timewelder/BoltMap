package com.boltmap.app.data.local.dao

import androidx.room.*
import com.boltmap.app.data.local.entity.BoltMarkerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BoltMarkerDao {

    @Query("SELECT * FROM bolt_markers WHERE photoId = :photoId ORDER BY boltNumber ASC")
    fun getMarkersForPhoto(photoId: Long): Flow<List<BoltMarkerEntity>>

    @Query("SELECT * FROM bolt_markers WHERE photoId = :photoId ORDER BY boltNumber ASC")
    suspend fun getMarkersForPhotoOnce(photoId: Long): List<BoltMarkerEntity>

    @Query("SELECT * FROM bolt_markers WHERE id = :markerId")
    suspend fun getMarkerById(markerId: Long): BoltMarkerEntity?

    @Query("SELECT MAX(boltNumber) FROM bolt_markers WHERE photoId = :photoId")
    suspend fun getMaxBoltNumber(photoId: Long): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarker(marker: BoltMarkerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarkers(markers: List<BoltMarkerEntity>)

    @Update
    suspend fun updateMarker(marker: BoltMarkerEntity)

    @Delete
    suspend fun deleteMarker(marker: BoltMarkerEntity)

    @Query("DELETE FROM bolt_markers WHERE photoId = :photoId")
    suspend fun deleteMarkersForPhoto(photoId: Long)

    @Query("DELETE FROM bolt_markers WHERE id = :markerId")
    suspend fun deleteMarkerById(markerId: Long)
}
