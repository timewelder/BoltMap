package com.boltmap.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "bolt_photos",
    foreignKeys = [
        ForeignKey(
            entity = JobEntity::class,
            parentColumns = ["id"],
            childColumns = ["jobId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("jobId")]
)
data class BoltPhotoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val jobId: Long,
    val photoPath: String,
    val label: String = "Before Teardown",
    val capturedAt: Long = System.currentTimeMillis(),
    val imageWidthPx: Int = 0,
    val imageHeightPx: Int = 0
)
