package com.boltmap.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "bolt_markers",
    foreignKeys = [
        ForeignKey(
            entity = BoltPhotoEntity::class,
            parentColumns = ["id"],
            childColumns = ["photoId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("photoId")]
)
data class BoltMarkerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val photoId: Long,
    // Normalized position (0.0 to 1.0) relative to image dimensions
    val normalizedX: Float,
    val normalizedY: Float,
    val boltNumber: Int,
    val torqueSpec: String = "",
    val notes: String = "",
    val isDetectedByAI: Boolean = false
)
