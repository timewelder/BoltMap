package com.boltmap.app.ui.job

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.boltmap.app.BoltMapApplication
import com.boltmap.app.data.repository.BoltPhoto
import com.boltmap.app.ui.components.*
import com.boltmap.app.ui.theme.*
import com.boltmap.app.viewmodel.JobDetailViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun JobDetailScreen(
    jobId: Long,
    onBack: () -> Unit,
    onCamera: () -> Unit,
    onTagBolts: (Long) -> Unit,
    onRebuild: (Long) -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as BoltMapApplication
    val viewModel: JobDetailViewModel = viewModel(
        factory = JobDetailViewModel.Factory(app.repository)
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(jobId) {
        viewModel.loadJob(jobId)
    }

    Scaffold(
        topBar = {
            BoltMapTopBar(
                title = uiState.job?.name ?: "Job",
                onBack = onBack
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onCamera,
                containerColor = BoltAmber,
                contentColor = VoidBlack,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.navigationBarsPadding()
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = "Capture photo",
                    modifier = Modifier.size(26.dp)
                )
            }
        },
        containerColor = VoidBlack
    ) { padding ->
        when {
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = BoltAmber)
                }
            }
            else -> {
                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 8.dp,
                        bottom = 100.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                ) {
                    // Job info header
                    item {
                        uiState.job?.let { job ->
                            BoltMapCard(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = job.category,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = BoltAmber
                                        )
                                        if (job.description.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = job.description,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = TextSecondary
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${uiState.photos.size}",
                                        fontSize = 28.sp,
                                        fontWeight = FontWeight.Black,
                                        color = BoltAmber
                                    )
                                }
                            }
                        }
                    }

                    if (uiState.photos.isEmpty()) {
                        item {
                            EmptyState(
                                icon = "📸",
                                title = "No photos yet",
                                subtitle = "Tap the camera button to capture your first bolt photo",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 48.dp)
                            )
                        }
                    } else {
                        item {
                            SectionLabel(
                                text = "${uiState.photos.size} Photo${if (uiState.photos.size != 1) "s" else ""}",
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                        items(
                            items = uiState.photos,
                            key = { it.id }
                        ) { photo ->
                            PhotoCard(
                                photo = photo,
                                onTagBolts = { onTagBolts(photo.id) },
                                onRebuild = { onRebuild(photo.id) },
                                onDelete = { viewModel.deletePhoto(photo.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PhotoCard(
    photo: BoltPhoto,
    onTagBolts: () -> Unit,
    onRebuild: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }

    BoltMapCard(modifier = Modifier.fillMaxWidth()) {
        // Photo thumbnail
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(File(photo.photoPath))
                .crossfade(true)
                .build(),
            contentDescription = "Bolt photo",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
        )

        // Actions row
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = photo.label,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.US)
                            .format(Date(photo.capturedAt)),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextTertiary
                    )
                }
                IconButton(
                    onClick = { showDeleteDialog = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete photo",
                        tint = TextTertiary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                SecondaryButton(
                    text = "Tag Bolts",
                    onClick = onTagBolts,
                    modifier = Modifier.weight(1f)
                )
                PrimaryButton(
                    text = "Rebuild",
                    onClick = onRebuild,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            containerColor = SurfaceDeep,
            title = { Text("Delete photo?", color = TextPrimary) },
            text = {
                Text(
                    "This photo and all its bolt markers will be permanently deleted.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    onDelete()
                }) {
                    Text("Delete", color = ErrorRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}
