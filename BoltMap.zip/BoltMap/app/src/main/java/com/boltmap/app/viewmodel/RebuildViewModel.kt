package com.boltmap.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.boltmap.app.data.repository.BoltMapRepository
import com.boltmap.app.data.repository.BoltMarker
import com.boltmap.app.data.repository.BoltPhoto
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class RebuildUiState(
    val photo: BoltPhoto? = null,
    val markers: List<BoltMarker> = emptyList(),
    val isLoading: Boolean = true,
    val highlightedBoltNumber: Int? = null,
    val error: String? = null
)

class RebuildViewModel(private val repository: BoltMapRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(RebuildUiState())
    val uiState: StateFlow<RebuildUiState> = _uiState.asStateFlow()

    fun loadPhoto(photoId: Long) {
        viewModelScope.launch {
            val photo = repository.getPhotoById(photoId)
            _uiState.update { it.copy(photo = photo, isLoading = false) }

            repository.getMarkersForPhoto(photoId)
                .catch { e -> _uiState.update { it.copy(error = e.message) } }
                .collect { markers ->
                    _uiState.update { it.copy(markers = markers) }
                }
        }
    }

    fun highlightBolt(number: Int?) {
        _uiState.update { it.copy(highlightedBoltNumber = number) }
    }

    class Factory(private val repository: BoltMapRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return RebuildViewModel(repository) as T
        }
    }
}
