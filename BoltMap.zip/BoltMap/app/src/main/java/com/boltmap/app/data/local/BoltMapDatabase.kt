package com.boltmap.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.boltmap.app.data.local.dao.BoltMarkerDao
import com.boltmap.app.data.local.dao.BoltPhotoDao
import com.boltmap.app.data.local.dao.JobDao
import com.boltmap.app.data.local.entity.BoltMarkerEntity
import com.boltmap.app.data.local.entity.BoltPhotoEntity
import com.boltmap.app.data.local.entity.JobEntity

@Database(
    entities = [
        JobEntity::class,
        BoltPhotoEntity::class,
        BoltMarkerEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BoltMapDatabase : RoomDatabase() {

    abstract fun jobDao(): JobDao
    abstract fun boltPhotoDao(): BoltPhotoDao
    abstract fun boltMarkerDao(): BoltMarkerDao

    companion object {
        @Volatile
        private var INSTANCE: BoltMapDatabase? = null

        fun getInstance(context: Context): BoltMapDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BoltMapDatabase::class.java,
                    "boltmap.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
