package com.boltmap.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary            = BoltAmber,
    onPrimary          = VoidBlack,
    primaryContainer   = BoltAmberDim,
    onPrimaryContainer = BoltAmber,

    secondary          = SteelBlue,
    onSecondary        = VoidBlack,
    secondaryContainer = SteelBlueDim,
    onSecondaryContainer = SteelBlue,

    background         = VoidBlack,
    onBackground       = TextPrimary,

    surface            = SurfaceDeep,
    onSurface          = TextPrimary,
    surfaceVariant     = SurfaceMid,
    onSurfaceVariant   = TextSecondary,

    outline            = OutlineColor,
    outlineVariant     = DividerColor,

    error              = ErrorRed,
    onError            = TextPrimary,

    inverseSurface     = TextPrimary,
    inverseOnSurface   = VoidBlack,
    inversePrimary     = BoltAmberDim
)

@Composable
fun BoltMapTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = BoltMapTypography,
        content     = content
    )
}
