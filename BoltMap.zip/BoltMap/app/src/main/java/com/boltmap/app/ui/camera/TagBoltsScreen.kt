package com.boltmap.app.ui.camera

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.boltmap.app.BoltMapApplication
import com.boltmap.app.data.repository.BoltMarker
import com.boltmap.app.ui.components.BoltMapTopBar
import com.boltmap.app.ui.components.BoltNumberBadge
import com.boltmap.app.ui.theme.*
import com.boltmap.app.viewmodel.TagBoltsViewModel
import java.io.File

@Composable
fun TagBoltsScreen(
    photoId: Long,
    onBack: () -> Unit,
    onDone: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as BoltMapApplication
    val viewModel: TagBoltsViewModel = viewModel(
        factory = TagBoltsViewModel.Factory(app.repository)
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(photoId) {
        viewModel.loadPhoto(photoId)
    }

    var selectedMarker by remember { mutableStateOf<BoltMarker?>(null) }
    var showMarkerDetail by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            BoltMapTopBar(
                title = "Tag Bolts",
                onBack = onBack,
                actions = {
                    if (uiState.markers.isNotEmpty()) {
                        TextButton(onClick = {
                            viewModel.clearAllMarkers()
                        }) {
                            Text("Clear All", color = ErrorRed)
                        }
                    }
                    IconButton(onClick = onDone) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Done",
                            tint = BoltAmber
                        )
                    }
                }
            )
        },
        containerColor = VoidBlack
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Instruction banner
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceMid)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "Tap on the photo to place bolt markers",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${uiState.markers.size} tagged",
                    style = MaterialTheme.typography.labelMedium,
                    color = BoltAmber,
                    fontWeight = FontWeight.Bold
                )
            }

            // Photo with tap-to-tag
            uiState.photo?.let { photo ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    PhotoWithMarkers(
                        photoPath = photo.photoPath,
                        markers = uiState.markers,
                        onTap = { nx, ny -> viewModel.addMarker(nx, ny) },
                        onMarkerTap = { marker ->
                            selectedMarker = marker
                            showMarkerDetail = true
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Bolt list strip
            if (uiState.markers.isNotEmpty()) {
                BoltListStrip(
                    markers = uiState.markers,
                    onMarkerTap = { marker ->
                        selectedMarker = marker
                        showMarkerDetail = true
                    },
                    onDeleteMarker = { viewModel.deleteMarker(it.id) }
                )
            }
        }
    }

    // Marker detail bottom sheet
    if (showMarkerDetail && selectedMarker != null) {
        MarkerDetailSheet(
            marker = selectedMarker!!,
            onDismiss = { showMarkerDetail = false },
            onDelete = {
                viewModel.deleteMarker(selectedMarker!!.id)
                showMarkerDetail = false
            },
            onSave = { notes, torque ->
                viewModel.updateMarkerNotes(selectedMarker!!.id, notes, torque)
                showMarkerDetail = false
            }
        )
    }
}

@Composable
fun PhotoWithMarkers(
    photoPath: String,
    markers: List<BoltMarker>,
    onTap: ((Float, Float) -> Unit)? = null,
    onMarkerTap: ((BoltMarker) -> Unit)? = null,
    highlightedBoltNumber: Int? = null,
    modifier: Modifier = Modifier
) {
    var imageSize by remember { mutableStateOf(IntSize.Zero) }

    Box(modifier = modifier) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(File(photoPath))
                .crossfade(false)
                .build(),
            contentDescription = "Bolt photo",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .onGloballyPositioned { coords ->
                    imageSize = coords.size
                }
                .then(
                    if (onTap != null) {
                        Modifier.pointerInput(Unit) {
                            detectTapGestures { offset ->
                                if (imageSize.width > 0 && imageSize.height > 0) {
                                    val nx = offset.x / imageSize.width
                                    val ny = offset.y / imageSize.height
                                    // Check if tap is on an existing marker
                                    val tapped = markers.find { marker ->
                                        val mx = marker.normalizedX * imageSize.width
                                        val my = marker.normalizedY * imageSize.height
                                        val dist = Offset(mx - offset.x, my - offset.y).getDistance()
                                        dist < 40f
                                    }
                                    if (tapped != null) {
                                        onMarkerTap?.invoke(tapped)
                                    } else {
                                        onTap(nx.coerceIn(0f, 1f), ny.coerceIn(0f, 1f))
                                    }
                                }
                            }
                        }
                    } else if (onMarkerTap != null) {
                        Modifier.pointerInput(Unit) {
                            detectTapGestures { offset ->
                                if (imageSize.width > 0 && imageSize.height > 0) {
                                    val tapped = markers.find { marker ->
                                        val mx = marker.normalizedX * imageSize.width
                                        val my = marker.normalizedY * imageSize.height
                                        val dist = Offset(mx - offset.x, my - offset.y).getDistance()
                                        dist < 48f
                                    }
                                    tapped?.let { onMarkerTap(it) }
                                }
                            }
                        }
                    } else Modifier
                )
        )

        // Draw markers
        markers.forEach { marker ->
            if (imageSize.width > 0 && imageSize.height > 0) {
                val x = marker.normalizedX * imageSize.width
                val y = marker.normalizedY * imageSize.height
                val isHighlighted = highlightedBoltNumber == marker.boltNumber
                val markerColor = MarkerColors[(marker.boltNumber - 1) % MarkerColors.size]

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .offset(
                            x = (x - 16).dp,
                            y = (y - 16).dp
                        )
                ) {
                    if (isHighlighted) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(
                                    markerColor.copy(alpha = 0.3f),
                                    CircleShape
                                )
                        )
                    }
                    BoltNumberBadge(
                        number = marker.boltNumber,
                        size = if (isHighlighted) 36.dp else 32.dp,
                        fontSize = if (isHighlighted) 14 else 12,
                        color = markerColor
                    )
                }
            }
        }
    }
}

@Composable
private fun BoltListStrip(
    markers: List<BoltMarker>,
    onMarkerTap: (BoltMarker) -> Unit,
    onDeleteMarker: (BoltMarker) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceDeep)
    ) {
        HorizontalDivider(color = DividerColor)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(markers, key = { it.id }) { marker ->
                val markerColor = MarkerColors[(marker.boltNumber - 1) % MarkerColors.size]
                Surface(
                    onClick = { onMarkerTap(marker) },
                    shape = RoundedCornerShape(10.dp),
                    color = SurfaceMid,
                    modifier = Modifier
                        .border(1.dp, markerColor.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        BoltNumberBadge(
                            number = marker.boltNumber,
                            size = 26.dp,
                            fontSize = 10,
                            color = markerColor
                        )
                        if (marker.torqueSpec.isNotBlank()) {
                            Text(
                                text = marker.torqueSpec,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                        IconButton(
                            onClick = { onDeleteMarker(marker) },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Remove bolt ${marker.boltNumber}",
                                tint = TextTertiary,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MarkerDetailSheet(
    marker: BoltMarker,
    onDismiss: () -> Unit,
    onDelete: () -> Unit,
    onSave: (notes: String, torque: String) -> Unit
) {
    var notes by remember(marker.id) { mutableStateOf(marker.notes) }
    var torque by remember(marker.id) { mutableStateOf(marker.torqueSpec) }
    val markerColor = MarkerColors[(marker.boltNumber - 1) % MarkerColors.size]

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDeep,
        sheetState = rememberModalBottomSheetState(skipPartialExpansion = true)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BoltNumberBadge(
                    number = marker.boltNumber,
                    size = 40.dp,
                    fontSize = 16,
                    color = markerColor
                )
                Text(
                    text = "Bolt ${marker.boltNumber}",
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete marker",
                        tint = ErrorRed
                    )
                }
            }

            OutlinedTextField(
                value = torque,
                onValueChange = { torque = it },
                label = { Text("Torque spec (e.g. 25 Nm)", color = TextTertiary) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = markerColor,
                    unfocusedBorderColor = OutlineColor,
                    cursorColor = markerColor,
                    focusedContainerColor = SurfaceMid,
                    unfocusedContainerColor = SurfaceDeep,
                    focusedLabelColor = markerColor
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes", color = TextTertiary) },
                minLines = 2,
                maxLines = 4,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = markerColor,
                    unfocusedBorderColor = OutlineColor,
                    cursorColor = markerColor,
                    focusedContainerColor = SurfaceMid,
                    unfocusedContainerColor = SurfaceDeep,
                    focusedLabelColor = markerColor
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Text("Cancel", color = TextSecondary)
                }
                Button(
                    onClick = { onSave(notes, torque) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = markerColor,
                        contentColor = VoidBlack
                    ),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
