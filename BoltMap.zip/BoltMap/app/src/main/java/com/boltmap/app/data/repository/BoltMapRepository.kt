package com.boltmap.app.data.repository

import com.boltmap.app.data.local.BoltMapDatabase
import com.boltmap.app.data.local.entity.BoltMarkerEntity
import com.boltmap.app.data.local.entity.BoltPhotoEntity
import com.boltmap.app.data.local.entity.JobEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class BoltMapRepository(private val database: BoltMapDatabase) {

    // ─── Jobs ───────────────────────────────────────────────────────────────

    fun getAllJobs(): Flow<List<Job>> =
        database.jobDao().getAllJobs().map { list ->
            list.map { it.toDomain() }
        }

    suspend fun getJobById(jobId: Long): Job? =
        database.jobDao().getJobById(jobId)?.toDomain()

    suspend fun createJob(name: String, category: String, description: String): Long {
        val entity = JobEntity(
            name = name,
            category = category,
            description = description
        )
        return database.jobDao().insertJob(entity)
    }

    suspend fun updateJob(job: Job) {
        database.jobDao().updateJob(job.toEntity())
    }

    suspend fun deleteJob(jobId: Long) {
        database.jobDao().deleteJobById(jobId)
    }

    // ─── Photos ─────────────────────────────────────────────────────────────

    fun getPhotosForJob(jobId: Long): Flow<List<BoltPhoto>> =
        database.boltPhotoDao().getPhotosForJob(jobId).map { list ->
            list.map { it.toDomain() }
        }

    suspend fun getPhotoById(photoId: Long): BoltPhoto? =
        database.boltPhotoDao().getPhotoById(photoId)?.toDomain()

    suspend fun getLatestPhotoForJob(jobId: Long): BoltPhoto? =
        database.boltPhotoDao().getLatestPhotoForJob(jobId)?.toDomain()

    suspend fun savePhoto(
        jobId: Long,
        photoPath: String,
        label: String = "Before Teardown",
        widthPx: Int = 0,
        heightPx: Int = 0
    ): Long {
        val entity = BoltPhotoEntity(
            jobId = jobId,
            photoPath = photoPath,
            label = label,
            imageWidthPx = widthPx,
            imageHeightPx = heightPx
        )
        // Update job's updatedAt timestamp
        database.jobDao().getJobById(jobId)?.let { job ->
            database.jobDao().updateJob(job.copy(updatedAt = System.currentTimeMillis()))
        }
        return database.boltPhotoDao().insertPhoto(entity)
    }

    suspend fun deletePhoto(photoId: Long) {
        database.boltPhotoDao().getPhotoById(photoId)?.let {
            database.boltPhotoDao().deletePhoto(it)
        }
    }

    // ─── Markers ────────────────────────────────────────────────────────────

    fun getMarkersForPhoto(photoId: Long): Flow<List<BoltMarker>> =
        database.boltMarkerDao().getMarkersForPhoto(photoId).map { list ->
            list.map { it.toDomain() }
        }

    suspend fun getMarkersForPhotoOnce(photoId: Long): List<BoltMarker> =
        database.boltMarkerDao().getMarkersForPhotoOnce(photoId).map { it.toDomain() }

    suspend fun addBoltMarker(
        photoId: Long,
        normalizedX: Float,
        normalizedY: Float,
        torqueSpec: String = "",
        notes: String = "",
        isAI: Boolean = false
    ): Long {
        val nextNumber = (database.boltMarkerDao().getMaxBoltNumber(photoId) ?: 0) + 1
        val entity = BoltMarkerEntity(
            photoId = photoId,
            normalizedX = normalizedX,
            normalizedY = normalizedY,
            boltNumber = nextNumber,
            torqueSpec = torqueSpec,
            notes = notes,
            isDetectedByAI = isAI
        )
        return database.boltMarkerDao().insertMarker(entity)
    }

    suspend fun updateMarker(marker: BoltMarker) {
        database.boltMarkerDao().updateMarker(marker.toEntity())
    }

    suspend fun deleteMarker(markerId: Long) {
        database.boltMarkerDao().deleteMarkerById(markerId)
    }

    suspend fun deleteAllMarkersForPhoto(photoId: Long) {
        database.boltMarkerDao().deleteMarkersForPhoto(photoId)
    }

    // ─── Mappers ────────────────────────────────────────────────────────────

    private fun JobEntity.toDomain() = Job(
        id = id,
        name = name,
        category = category,
        description = description,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun Job.toEntity() = JobEntity(
        id = id,
        name = name,
        category = category,
        description = description,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun BoltPhotoEntity.toDomain() = BoltPhoto(
        id = id,
        jobId = jobId,
        photoPath = photoPath,
        label = label,
        capturedAt = capturedAt,
        imageWidthPx = imageWidthPx,
        imageHeightPx = imageHeightPx
    )

    private fun BoltMarkerEntity.toDomain() = BoltMarker(
        id = id,
        photoId = photoId,
        normalizedX = normalizedX,
        normalizedY = normalizedY,
        boltNumber = boltNumber,
        torqueSpec = torqueSpec,
        notes = notes,
        isDetectedByAI = isDetectedByAI
    )

    private fun BoltMarker.toEntity() = BoltMarkerEntity(
        id = id,
        photoId = photoId,
        normalizedX = normalizedX,
        normalizedY = normalizedY,
        boltNumber = boltNumber,
        torqueSpec = torqueSpec,
        notes = notes,
        isDetectedByAI = isDetectedByAI
    )
}
