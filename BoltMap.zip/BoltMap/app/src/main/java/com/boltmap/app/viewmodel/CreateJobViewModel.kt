package com.boltmap.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.boltmap.app.data.repository.BoltMapRepository
import com.boltmap.app.data.repository.JobCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CreateJobUiState(
    val name: String = "",
    val description: String = "",
    val selectedCategory: JobCategory = JobCategory.ENGINE,
    val isSaving: Boolean = false,
    val savedJobId: Long? = null,
    val error: String? = null
)

class CreateJobViewModel(private val repository: BoltMapRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(CreateJobUiState())
    val uiState: StateFlow<CreateJobUiState> = _uiState.asStateFlow()

    fun onNameChange(name: String) {
        _uiState.update { it.copy(name = name, error = null) }
    }

    fun onDescriptionChange(desc: String) {
        _uiState.update { it.copy(description = desc) }
    }

    fun onCategoryChange(category: JobCategory) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun createJob() {
        val state = _uiState.value
        if (state.name.isBlank()) {
            _uiState.update { it.copy(error = "Job name cannot be empty") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            try {
                val id = repository.createJob(
                    name = state.name.trim(),
                    category = state.selectedCategory.displayName,
                    description = state.description.trim()
                )
                _uiState.update { it.copy(isSaving = false, savedJobId = id) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isSaving = false, error = e.message ?: "Failed to create job") }
            }
        }
    }

    class Factory(private val repository: BoltMapRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return CreateJobViewModel(repository) as T
        }
    }
}
