package com.boltmap.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.boltmap.app.data.repository.BoltMapRepository
import com.boltmap.app.data.repository.BoltMarker
import com.boltmap.app.data.repository.BoltPhoto
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class TagBoltsUiState(
    val photo: BoltPhoto? = null,
    val markers: List<BoltMarker> = emptyList(),
    val isLoading: Boolean = true,
    val selectedMarkerId: Long? = null,
    val isSaving: Boolean = false,
    val error: String? = null
)

class TagBoltsViewModel(private val repository: BoltMapRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(TagBoltsUiState())
    val uiState: StateFlow<TagBoltsUiState> = _uiState.asStateFlow()

    private var currentPhotoId: Long = 0

    fun loadPhoto(photoId: Long) {
        currentPhotoId = photoId
        viewModelScope.launch {
            val photo = repository.getPhotoById(photoId)
            _uiState.update { it.copy(photo = photo, isLoading = false) }

            repository.getMarkersForPhoto(photoId)
                .catch { e -> _uiState.update { it.copy(error = e.message) } }
                .collect { markers ->
                    _uiState.update { it.copy(markers = markers) }
                }
        }
    }

    fun addMarker(normalizedX: Float, normalizedY: Float) {
        viewModelScope.launch {
            try {
                repository.addBoltMarker(
                    photoId = currentPhotoId,
                    normalizedX = normalizedX,
                    normalizedY = normalizedY
                )
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    fun selectMarker(markerId: Long?) {
        _uiState.update { it.copy(selectedMarkerId = markerId) }
    }

    fun deleteMarker(markerId: Long) {
        viewModelScope.launch {
            repository.deleteMarker(markerId)
            if (_uiState.value.selectedMarkerId == markerId) {
                _uiState.update { it.copy(selectedMarkerId = null) }
            }
        }
    }

    fun updateMarkerNotes(markerId: Long, notes: String, torque: String) {
        viewModelScope.launch {
            val marker = _uiState.value.markers.find { it.id == markerId } ?: return@launch
            repository.updateMarker(marker.copy(notes = notes, torqueSpec = torque))
        }
    }

    fun clearAllMarkers() {
        viewModelScope.launch {
            repository.deleteAllMarkersForPhoto(currentPhotoId)
        }
    }

    class Factory(private val repository: BoltMapRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return TagBoltsViewModel(repository) as T
        }
    }
}
