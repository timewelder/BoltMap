package com.boltmap.app.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.boltmap.app.BoltMapApplication
import com.boltmap.app.data.repository.Job
import com.boltmap.app.data.repository.JobCategory
import com.boltmap.app.ui.components.*
import com.boltmap.app.ui.theme.*
import com.boltmap.app.viewmodel.HomeViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    onCreateJob: () -> Unit,
    onJobSelected: (Long) -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as BoltMapApplication
    val viewModel: HomeViewModel = viewModel(
        factory = HomeViewModel.Factory(app.repository)
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .background(VoidBlack)
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "BOLTMAP",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = BoltAmber,
                    letterSpacing = 4.sp
                )
                Text(
                    text = "My Jobs",
                    style = MaterialTheme.typography.displayMedium,
                    color = TextPrimary
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onCreateJob,
                containerColor = BoltAmber,
                contentColor = VoidBlack,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.navigationBarsPadding()
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Create new job",
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        containerColor = VoidBlack
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                uiState.isLoading -> {
                    CircularProgressIndicator(
                        color = BoltAmber,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                uiState.jobs.isEmpty() -> {
                    EmptyState(
                        icon = "🔧",
                        title = "No jobs yet",
                        subtitle = "Tap the + button to create your first job and start tracking bolts",
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                else -> {
                    LazyColumn(
                        contentPadding = PaddingValues(
                            horizontal = 16.dp,
                            vertical = 8.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            Text(
                                text = "${uiState.jobs.size} job${if (uiState.jobs.size != 1) "s" else ""}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextTertiary,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(
                            items = uiState.jobs,
                            key = { it.id }
                        ) { job ->
                            JobCard(
                                job = job,
                                onClick = { onJobSelected(job.id) },
                                onDelete = { viewModel.deleteJob(job) }
                            )
                        }
                        item { Spacer(modifier = Modifier.height(80.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun JobCard(
    job: Job,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }

    val categoryIcon = JobCategory.entries
        .find { it.displayName == job.category }?.icon ?: "🔧"

    BoltMapCard(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Category icon badge
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceMid)
            ) {
                Text(text = categoryIcon, fontSize = 22.sp)
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = job.name,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = job.category,
                    style = MaterialTheme.typography.bodyMedium,
                    color = BoltAmber
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = formatDate(job.updatedAt),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextTertiary
                )
            }

            IconButton(
                onClick = { showDeleteDialog = true },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete job",
                    tint = TextTertiary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        if (job.description.isNotBlank()) {
            HorizontalDivider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
            Text(
                text = job.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextTertiary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            containerColor = SurfaceDeep,
            title = {
                Text("Delete job?", color = TextPrimary)
            },
            text = {
                Text(
                    "\"${job.name}\" and all its photos will be permanently deleted.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        onDelete()
                    }
                ) {
                    Text("Delete", color = ErrorRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

private fun formatDate(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val diff = now - timestamp
    return when {
        diff < 60_000 -> "Just now"
        diff < 3_600_000 -> "${diff / 60_000}m ago"
        diff < 86_400_000 -> "${diff / 3_600_000}h ago"
        diff < 604_800_000 -> "${diff / 86_400_000}d ago"
        else -> SimpleDateFormat("MMM d, yyyy", Locale.US).format(Date(timestamp))
    }
}
