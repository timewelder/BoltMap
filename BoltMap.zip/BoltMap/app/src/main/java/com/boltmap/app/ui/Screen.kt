package com.boltmap.app.ui

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object CreateJob : Screen("create_job")
    object JobDetail : Screen("job_detail/{jobId}") {
        fun createRoute(jobId: Long) = "job_detail/$jobId"
    }
    object Camera : Screen("camera/{jobId}") {
        fun createRoute(jobId: Long) = "camera/$jobId"
    }
    object TagBolts : Screen("tag_bolts/{photoId}") {
        fun createRoute(photoId: Long) = "tag_bolts/$photoId"
    }
    object Rebuild : Screen("rebuild/{photoId}") {
        fun createRoute(photoId: Long) = "rebuild/$photoId"
    }
}
