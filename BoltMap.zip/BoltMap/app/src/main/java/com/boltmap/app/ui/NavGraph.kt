package com.boltmap.app.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.boltmap.app.ui.camera.CameraScreen
import com.boltmap.app.ui.camera.TagBoltsScreen
import com.boltmap.app.ui.home.HomeScreen
import com.boltmap.app.ui.job.CreateJobScreen
import com.boltmap.app.ui.job.JobDetailScreen
import com.boltmap.app.ui.rebuild.RebuildScreen

@Composable
fun BoltMapNavGraph(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onCreateJob = { navController.navigate(Screen.CreateJob.route) },
                onJobSelected = { jobId ->
                    navController.navigate(Screen.JobDetail.createRoute(jobId))
                }
            )
        }

        composable(Screen.CreateJob.route) {
            CreateJobScreen(
                onBack = { navController.popBackStack() },
                onJobCreated = { jobId ->
                    // Pop create screen and navigate to detail
                    navController.popBackStack()
                    navController.navigate(Screen.JobDetail.createRoute(jobId))
                }
            )
        }

        composable(
            route = Screen.JobDetail.route,
            arguments = listOf(navArgument("jobId") { type = NavType.LongType })
        ) { backStackEntry ->
            val jobId = backStackEntry.arguments?.getLong("jobId") ?: return@composable
            JobDetailScreen(
                jobId = jobId,
                onBack = { navController.popBackStack() },
                onCamera = { navController.navigate(Screen.Camera.createRoute(jobId)) },
                onTagBolts = { photoId ->
                    navController.navigate(Screen.TagBolts.createRoute(photoId))
                },
                onRebuild = { photoId ->
                    navController.navigate(Screen.Rebuild.createRoute(photoId))
                }
            )
        }

        composable(
            route = Screen.Camera.route,
            arguments = listOf(navArgument("jobId") { type = NavType.LongType })
        ) { backStackEntry ->
            val jobId = backStackEntry.arguments?.getLong("jobId") ?: return@composable
            CameraScreen(
                jobId = jobId,
                onBack = { navController.popBackStack() },
                onPhotoTaken = { photoId ->
                    // Pop camera then go to tag screen
                    navController.popBackStack()
                    navController.navigate(Screen.TagBolts.createRoute(photoId))
                }
            )
        }

        composable(
            route = Screen.TagBolts.route,
            arguments = listOf(navArgument("photoId") { type = NavType.LongType })
        ) { backStackEntry ->
            val photoId = backStackEntry.arguments?.getLong("photoId") ?: return@composable
            TagBoltsScreen(
                photoId = photoId,
                onBack = { navController.popBackStack() },
                onDone = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.Rebuild.route,
            arguments = listOf(navArgument("photoId") { type = NavType.LongType })
        ) { backStackEntry ->
            val photoId = backStackEntry.arguments?.getLong("photoId") ?: return@composable
            RebuildScreen(
                photoId = photoId,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
