package com.boltmap.app.ui.job

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.boltmap.app.BoltMapApplication
import com.boltmap.app.data.repository.JobCategory
import com.boltmap.app.ui.components.*
import com.boltmap.app.ui.theme.*
import com.boltmap.app.viewmodel.CreateJobViewModel

@Composable
fun CreateJobScreen(
    onBack: () -> Unit,
    onJobCreated: (Long) -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as BoltMapApplication
    val viewModel: CreateJobViewModel = viewModel(
        factory = CreateJobViewModel.Factory(app.repository)
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Navigate when job is saved
    LaunchedEffect(uiState.savedJobId) {
        uiState.savedJobId?.let { id -> onJobCreated(id) }
    }

    Scaffold(
        topBar = {
            BoltMapTopBar(
                title = "New Job",
                onBack = onBack
            )
        },
        containerColor = VoidBlack
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Job Name
            Column {
                SectionLabel(text = "Job Name")
                OutlinedTextField(
                    value = uiState.name,
                    onValueChange = viewModel::onNameChange,
                    placeholder = {
                        Text("e.g. Engine head rebuild", color = TextTertiary)
                    },
                    singleLine = true,
                    isError = uiState.error != null,
                    supportingText = uiState.error?.let { err ->
                        { Text(err, color = ErrorRed) }
                    },
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Words,
                        imeAction = ImeAction.Next
                    ),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = BoltAmber,
                        unfocusedBorderColor = OutlineColor,
                        cursorColor = BoltAmber,
                        focusedContainerColor = SurfaceMid,
                        unfocusedContainerColor = SurfaceDeep,
                        errorBorderColor = ErrorRed,
                        errorContainerColor = SurfaceDeep
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Description
            Column {
                SectionLabel(text = "Description (optional)")
                OutlinedTextField(
                    value = uiState.description,
                    onValueChange = viewModel::onDescriptionChange,
                    placeholder = {
                        Text("Add any notes about this job…", color = TextTertiary)
                    },
                    minLines = 3,
                    maxLines = 5,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        imeAction = ImeAction.Done
                    ),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = BoltAmber,
                        unfocusedBorderColor = OutlineColor,
                        cursorColor = BoltAmber,
                        focusedContainerColor = SurfaceMid,
                        unfocusedContainerColor = SurfaceDeep
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Category Grid
            Column {
                SectionLabel(text = "Category")
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    // Make grid not scroll (parent scrolls)
                    modifier = Modifier.heightIn(max = 400.dp)
                ) {
                    items(JobCategory.entries) { category ->
                        CategoryChip(
                            label = category.displayName,
                            icon = category.icon,
                            selected = uiState.selectedCategory == category,
                            onClick = { viewModel.onCategoryChange(category) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Create button
            PrimaryButton(
                text = if (uiState.isSaving) "Creating…" else "Create Job",
                onClick = viewModel::createJob,
                enabled = !uiState.isSaving && uiState.name.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.navigationBarsPadding())
        }
    }
}
