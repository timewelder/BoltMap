package com.boltmap.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.boltmap.app.data.repository.BoltMapRepository
import com.boltmap.app.data.repository.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class HomeUiState(
    val jobs: List<Job> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

class HomeViewModel(private val repository: BoltMapRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadJobs()
    }

    private fun loadJobs() {
        viewModelScope.launch {
            repository.getAllJobs()
                .catch { e ->
                    _uiState.update { it.copy(isLoading = false, error = e.message) }
                }
                .collect { jobs ->
                    _uiState.update { it.copy(jobs = jobs, isLoading = false) }
                }
        }
    }

    fun deleteJob(job: Job) {
        viewModelScope.launch {
            repository.deleteJob(job.id)
        }
    }

    class Factory(private val repository: BoltMapRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return HomeViewModel(repository) as T
        }
    }
}
