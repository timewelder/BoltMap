package com.boltmap.app

import android.app.Application
import com.boltmap.app.data.local.BoltMapDatabase
import com.boltmap.app.data.repository.BoltDetector
import com.boltmap.app.data.repository.BoltMapRepository

class BoltMapApplication : Application() {

    val database: BoltMapDatabase by lazy {
        BoltMapDatabase.getInstance(this)
    }

    val repository: BoltMapRepository by lazy {
        BoltMapRepository(database)
    }

    val boltDetector: BoltDetector by lazy {
        BoltDetector(this)
    }

    override fun onCreate() {
        super.onCreate()
        // Initialise detector on background thread so it doesn't block startup
        Thread {
            boltDetector.initialize()
        }.start()
    }
}
