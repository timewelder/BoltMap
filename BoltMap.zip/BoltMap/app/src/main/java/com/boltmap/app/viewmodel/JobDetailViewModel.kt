package com.boltmap.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.boltmap.app.data.repository.BoltMapRepository
import com.boltmap.app.data.repository.BoltPhoto
import com.boltmap.app.data.repository.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class JobDetailUiState(
    val job: Job? = null,
    val photos: List<BoltPhoto> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

class JobDetailViewModel(private val repository: BoltMapRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(JobDetailUiState())
    val uiState: StateFlow<JobDetailUiState> = _uiState.asStateFlow()

    fun loadJob(jobId: Long) {
        viewModelScope.launch {
            val job = repository.getJobById(jobId)
            _uiState.update { it.copy(job = job) }

            repository.getPhotosForJob(jobId)
                .catch { e -> _uiState.update { it.copy(isLoading = false, error = e.message) } }
                .collect { photos ->
                    _uiState.update { it.copy(photos = photos, isLoading = false) }
                }
        }
    }

    fun deletePhoto(photoId: Long) {
        viewModelScope.launch {
            repository.deletePhoto(photoId)
        }
    }

    class Factory(private val repository: BoltMapRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return JobDetailViewModel(repository) as T
        }
    }
}
