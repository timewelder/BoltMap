package com.boltmap.app.data.local.dao

import androidx.room.*
import com.boltmap.app.data.local.entity.BoltPhotoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BoltPhotoDao {

    @Query("SELECT * FROM bolt_photos WHERE jobId = :jobId ORDER BY capturedAt DESC")
    fun getPhotosForJob(jobId: Long): Flow<List<BoltPhotoEntity>>

    @Query("SELECT * FROM bolt_photos WHERE id = :photoId")
    suspend fun getPhotoById(photoId: Long): BoltPhotoEntity?

    @Query("SELECT * FROM bolt_photos WHERE jobId = :jobId ORDER BY capturedAt DESC LIMIT 1")
    suspend fun getLatestPhotoForJob(jobId: Long): BoltPhotoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhoto(photo: BoltPhotoEntity): Long

    @Update
    suspend fun updatePhoto(photo: BoltPhotoEntity)

    @Delete
    suspend fun deletePhoto(photo: BoltPhotoEntity)

    @Query("DELETE FROM bolt_photos WHERE jobId = :jobId")
    suspend fun deletePhotosForJob(jobId: Long)
}
