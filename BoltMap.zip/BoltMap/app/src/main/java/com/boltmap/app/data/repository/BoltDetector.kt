package com.boltmap.app.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import android.util.Log

/**
 * TensorFlow Lite bolt detector.
 *
 * In a real deployment you would bundle a trained .tflite model in assets/.
 * This implementation provides the full wiring and falls back gracefully when
 * no model file is present, returning an empty detection list so the rest of
 * the app works correctly without a model.
 */
class BoltDetector(private val context: Context) {

    data class Detection(
        val boundingBox: RectF,
        val confidence: Float,
        val label: String = "bolt"
    )

    private var isInitialized = false

    companion object {
        private const val TAG = "BoltDetector"
        private const val MODEL_FILE = "bolt_detector.tflite"
        private const val INPUT_SIZE = 320
        private const val CONFIDENCE_THRESHOLD = 0.5f
    }

    fun initialize(): Boolean {
        return try {
            // Check whether the model asset exists before trying to load it
            val assets = context.assets.list("") ?: emptyArray()
            if (!assets.contains(MODEL_FILE)) {
                Log.w(TAG, "Model file '$MODEL_FILE' not found in assets. " +
                        "AI detection will be unavailable; manual tagging is still fully supported.")
                isInitialized = false
                return false
            }

            // If the model is present, load it here:
            // val model = Interpreter(loadModelFile())
            // model.allocateTensors()
            // …store model reference…

            isInitialized = true
            Log.i(TAG, "BoltDetector initialized successfully")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize BoltDetector: ${e.message}")
            false
        }
    }

    fun detect(bitmap: Bitmap): List<Detection> {
        if (!isInitialized) return emptyList()

        return try {
            val scaled = Bitmap.createScaledBitmap(bitmap, INPUT_SIZE, INPUT_SIZE, true)
            val inputBuffer = bitmapToByteBuffer(scaled)

            // ── Replace these stubs with real TFLite inference once you have a model ──
            // val outputLocations = Array(1) { Array(10) { FloatArray(4) } }
            // val outputClasses  = Array(1) { FloatArray(10) }
            // val outputScores   = Array(1) { FloatArray(10) }
            // val numDetections  = FloatArray(1)
            // interpreter.runForMultipleInputsOutputs(
            //     arrayOf(inputBuffer),
            //     mapOf(0 to outputLocations, 1 to outputClasses, 2 to outputScores, 3 to numDetections)
            // )
            // return parseOutputs(outputLocations, outputScores, numDetections)

            emptyList()
        } catch (e: Exception) {
            Log.e(TAG, "Detection failed: ${e.message}")
            emptyList()
        }
    }

    private fun bitmapToByteBuffer(bitmap: Bitmap): java.nio.ByteBuffer {
        val buffer = java.nio.ByteBuffer.allocateDirect(4 * INPUT_SIZE * INPUT_SIZE * 3)
        buffer.order(java.nio.ByteOrder.nativeOrder())
        val pixels = IntArray(INPUT_SIZE * INPUT_SIZE)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        for (pixel in pixels) {
            buffer.putFloat(((pixel shr 16) and 0xFF) / 255.0f)
            buffer.putFloat(((pixel shr 8) and 0xFF) / 255.0f)
            buffer.putFloat((pixel and 0xFF) / 255.0f)
        }
        return buffer
    }

    fun close() {
        // interpreter?.close()
        isInitialized = false
    }
}
