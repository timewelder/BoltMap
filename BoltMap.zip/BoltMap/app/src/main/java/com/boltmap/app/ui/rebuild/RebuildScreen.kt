package com.boltmap.app.ui.rebuild

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.boltmap.app.BoltMapApplication
import com.boltmap.app.data.repository.BoltMarker
import com.boltmap.app.ui.camera.PhotoWithMarkers
import com.boltmap.app.ui.components.BoltMapTopBar
import com.boltmap.app.ui.components.BoltNumberBadge
import com.boltmap.app.ui.components.EmptyState
import com.boltmap.app.ui.theme.*
import com.boltmap.app.viewmodel.RebuildViewModel

@Composable
fun RebuildScreen(
    photoId: Long,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as BoltMapApplication
    val viewModel: RebuildViewModel = viewModel(
        factory = RebuildViewModel.Factory(app.repository)
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(photoId) {
        viewModel.loadPhoto(photoId)
    }

    Scaffold(
        topBar = {
            BoltMapTopBar(
                title = "Rebuild Guide",
                onBack = onBack
            )
        },
        containerColor = VoidBlack
    ) { padding ->
        when {
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = BoltAmber)
                }
            }
            uiState.photo == null -> {
                EmptyState(
                    icon = "❌",
                    title = "Photo not found",
                    subtitle = "This photo may have been deleted",
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                )
            }
            else -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentPadding = PaddingValues(bottom = 32.dp)
                ) {
                    // Photo with bolt overlays (non-interactive)
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(300.dp)
                                .background(SurfaceDeep)
                        ) {
                            uiState.photo?.let { photo ->
                                PhotoWithMarkers(
                                    photoPath = photo.photoPath,
                                    markers = uiState.markers,
                                    highlightedBoltNumber = uiState.highlightedBoltNumber,
                                    onMarkerTap = { marker ->
                                        viewModel.highlightBolt(
                                            if (uiState.highlightedBoltNumber == marker.boltNumber) null
                                            else marker.boltNumber
                                        )
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }

                    // Stats row
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SurfaceMid)
                                .padding(horizontal = 20.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = uiState.photo?.label ?: "",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Tap a bolt number to highlight it",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextTertiary
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = BoltAmberGlow
                            ) {
                                Text(
                                    text = "${uiState.markers.size} bolts",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = BoltAmber,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    if (uiState.markers.isEmpty()) {
                        item {
                            EmptyState(
                                icon = "🔩",
                                title = "No bolts tagged",
                                subtitle = "Go back and use 'Tag Bolts' to mark bolt positions",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 32.dp)
                            )
                        }
                    } else {
                        // Bolt reference list
                        item {
                            Text(
                                text = "BOLT REFERENCE",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextTertiary,
                                letterSpacing = androidx.compose.ui.unit.TextUnit(1.5f, androidx.compose.ui.unit.TextUnitType.Sp),
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                            )
                        }

                        items(uiState.markers, key = { it.id }) { marker ->
                            BoltReferenceRow(
                                marker = marker,
                                isHighlighted = uiState.highlightedBoltNumber == marker.boltNumber,
                                onClick = {
                                    viewModel.highlightBolt(
                                        if (uiState.highlightedBoltNumber == marker.boltNumber) null
                                        else marker.boltNumber
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BoltReferenceRow(
    marker: BoltMarker,
    isHighlighted: Boolean,
    onClick: () -> Unit
) {
    val markerColor = MarkerColors[(marker.boltNumber - 1) % MarkerColors.size]

    Surface(
        onClick = onClick,
        color = if (isHighlighted) markerColor.copy(alpha = 0.08f) else SurfaceDeep,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            BoltNumberBadge(
                number = marker.boltNumber,
                size = 38.dp,
                fontSize = 14,
                color = markerColor
            )

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Bolt ${marker.boltNumber}",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (isHighlighted) markerColor else TextPrimary,
                        fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal
                    )
                    if (marker.torqueSpec.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = markerColor.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = marker.torqueSpec,
                                style = MaterialTheme.typography.labelSmall,
                                color = markerColor,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
                if (marker.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = marker.notes,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                if (marker.isDetectedByAI) {
                    Text(
                        text = "AI detected",
                        style = MaterialTheme.typography.labelSmall,
                        color = SteelBlue
                    )
                }
            }
        }

        HorizontalDivider(
            color = DividerColor,
            modifier = Modifier.padding(horizontal = 20.dp)
        )
    }
}
