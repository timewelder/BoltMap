package com.boltmap.app.data.repository

data class Job(
    val id: Long = 0,
    val name: String,
    val category: String,
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class BoltPhoto(
    val id: Long = 0,
    val jobId: Long,
    val photoPath: String,
    val label: String = "Before Teardown",
    val capturedAt: Long = System.currentTimeMillis(),
    val imageWidthPx: Int = 0,
    val imageHeightPx: Int = 0
)

data class BoltMarker(
    val id: Long = 0,
    val photoId: Long,
    val normalizedX: Float,
    val normalizedY: Float,
    val boltNumber: Int,
    val torqueSpec: String = "",
    val notes: String = "",
    val isDetectedByAI: Boolean = false
)

data class JobWithPhotos(
    val job: Job,
    val photos: List<BoltPhoto> = emptyList()
)

data class PhotoWithMarkers(
    val photo: BoltPhoto,
    val markers: List<BoltMarker> = emptyList()
)

enum class JobCategory(val displayName: String, val icon: String) {
    ENGINE("Engine", "🔧"),
    GEARBOX("Gearbox", "⚙️"),
    BRAKES("Brakes", "🛑"),
    SUSPENSION("Suspension", "🔩"),
    EXHAUST("Exhaust", "💨"),
    ELECTRICAL("Electrical", "⚡"),
    BODYWORK("Bodywork", "🔨"),
    COOLING("Cooling", "❄️"),
    FUEL_SYSTEM("Fuel System", "⛽"),
    GENERAL("General", "🔧")
}
