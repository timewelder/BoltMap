package com.boltmap.app.ui.theme

import androidx.compose.ui.graphics.Color

// ── BoltMap Dark Industrial Palette ───────────────────────────────────────────
// Inspired by workshop environments: deep blacks, amber warning tones, steel greys

val VoidBlack      = Color(0xFF0A0A0F)   // True background
val SurfaceDeep    = Color(0xFF12121A)   // Card background
val SurfaceMid     = Color(0xFF1C1C28)   // Elevated surface
val SurfaceHigh    = Color(0xFF252535)   // Highest surface / sheets

val BoltAmber      = Color(0xFFFFB020)   // Primary accent — warning / active bolt
val BoltAmberDim   = Color(0xFF7A5410)   // Pressed / disabled amber
val BoltAmberGlow  = Color(0x33FFB020)   // Ambient amber glow

val SteelBlue      = Color(0xFF4A9EFF)   // Secondary accent — info / links
val SteelBlueDim   = Color(0xFF1A4070)

val SuccessGreen   = Color(0xFF2ECC71)
val ErrorRed       = Color(0xFFE74C3C)
val WarningOrange  = Color(0xFFF39C12)

val TextPrimary    = Color(0xFFEEEEF4)
val TextSecondary  = Color(0xFF8888A0)
val TextTertiary   = Color(0xFF55556A)

val DividerColor   = Color(0xFF252535)
val OutlineColor   = Color(0xFF333348)

// Bolt number marker colours (cycles through)
val MarkerColors = listOf(
    Color(0xFFFFB020), // amber
    Color(0xFF4A9EFF), // steel blue
    Color(0xFF2ECC71), // green
    Color(0xFFE74C3C), // red
    Color(0xFF9B59B6), // purple
    Color(0xFF1ABC9C), // teal
    Color(0xFFF39C12), // orange
    Color(0xFF3498DB), // blue
)
