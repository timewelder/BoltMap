package com.boltmap.app.viewmodel

import android.content.Context
import android.graphics.BitmapFactory
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.boltmap.app.data.repository.BoltMapRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CameraUiState(
    val jobId: Long = 0,
    val isCapturing: Boolean = false,
    val capturedPhotoPath: String? = null,
    val savedPhotoId: Long? = null,
    val error: String? = null
)

class CameraViewModel(private val repository: BoltMapRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(CameraUiState())
    val uiState: StateFlow<CameraUiState> = _uiState.asStateFlow()

    fun setJobId(jobId: Long) {
        _uiState.update { it.copy(jobId = jobId) }
    }

    fun capturePhoto(
        imageCapture: ImageCapture,
        context: Context,
        onPhotoSaved: (Long) -> Unit
    ) {
        val jobId = _uiState.value.jobId
        _uiState.update { it.copy(isCapturing = true) }

        val photoDir = File(context.filesDir, "images").apply { mkdirs() }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val photoFile = File(photoDir, "BOLT_${timestamp}.jpg")

        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val path = photoFile.absolutePath
                    // Read image dimensions
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(path, opts)
                    val w = opts.outWidth
                    val h = opts.outHeight

                    viewModelScope.launch {
                        try {
                            val photoId = repository.savePhoto(
                                jobId = jobId,
                                photoPath = path,
                                label = "Before Teardown",
                                widthPx = w,
                                heightPx = h
                            )
                            _uiState.update {
                                it.copy(
                                    isCapturing = false,
                                    capturedPhotoPath = path,
                                    savedPhotoId = photoId
                                )
                            }
                            onPhotoSaved(photoId)
                        } catch (e: Exception) {
                            _uiState.update {
                                it.copy(isCapturing = false, error = e.message)
                            }
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    _uiState.update {
                        it.copy(isCapturing = false, error = exception.message)
                    }
                }
            }
        )
    }

    class Factory(private val repository: BoltMapRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return CameraViewModel(repository) as T
        }
    }
}
